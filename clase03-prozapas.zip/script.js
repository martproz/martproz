//FOR
for (let i = 10; i >=1; i--) {
    console.log(`Contador para la explosión de la bomba ${i}`);
  }
  console.log('Boom y comienzo de WHILE');
  
  //WHILE
  let x = 1;
  while (x <= 4) {
    console.log(`Iteracion ${x}`);
    x++;
  }
  console.log('Fin de WHILE y comienzo de DO WHILE');
  
  //DO WHILE
  let y = 1;
  do {
    console.log(`Iteracion ${y}`);
    y++;
  } while (y <= 4);